<template>
    <div>
      <span>{{ item.name }} - {{ item.quantity }} x {{ item.price }} Ft = {{ item.quantity * item.price }} Ft</span>
      <button v-show="item.quantity > 0" @click="$emit('remove-item')">Törlés</button>
    </div>
  </template>
  
  <script>
  export default {
    props: {
      item: {
        type: Object,
        required: true,
      },
    },
  };
  </script>
  
  <style scoped>
  button {
    margin-left: 10px;
    padding: 8px 10px;
    background-color: rgb(255, 0, 0);
    color: white;
    border: none;
    cursor: pointer;
    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
  }
  button:hover {
    background-color: #cc2b26;
  }
  </style>
  