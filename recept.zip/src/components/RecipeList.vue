<template>
  <div class="recipe-list">
    <div 
      v-for="(recipe, index) in recipes" 
      :key="index" 
      class="bg-white shadow-md rounded p-4 mb-4"
    >
      <h2 class="text-xl font-bold">{{ recipe.name }}</h2>
      <p class="italic">Elkészítési idő: {{ recipe.time }} perc</p>
      <h3 class="font-semibold mt-2">Hozzávalók:</h3>
      <ul class="list-disc list-inside">
        <li v-for="(ingredient, idx) in recipe.ingredients" :key="idx">{{ ingredient }}</li>
      </ul>
      <h3 class="font-semibold mt-2">Leírás:</h3>
      <p>{{ recipe.description }}</p>
      <button 
        @click="$emit('deleteRecipe', index)" 
        class="bg-red-500 text-white px-4 py-2 rounded mt-2"
      >
        Törlés
      </button>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    recipes: Array,
  },
};
</script>
