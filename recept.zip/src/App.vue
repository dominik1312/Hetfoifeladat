<template>
  <div class="container">
    <h1>Receptkönyv</h1>
    <div class="input-group">
      <input v-model="newItem.name" placeholder="Termék neve" />
      <input v-model.number="newItem.quantity" type="number" placeholder="Mennyiség" />
      <input v-model.number="newItem.price" type="number" placeholder="Ár" />
      <button @click="addItem">Hozzáadás</button>
    </div>

    
    <ul>
      <li v-for="(item, index) in items" :key="index">
        <ShoppingItem
          :item="item"
          @remove-item="removeItem(index)"
        />
      </li>
    </ul>

  
    <div v-if="items.length > 0">
      <h3>Összesített ár: {{ totalPrice }} Ft</h3>
    </div>
  </div>
</template>

<script>
import ShoppingItem from './components/HelloWorld.vue';

export default {
  components: {
    ShoppingItem,
  },
  data() {
    return {
      newItem: {
        name: '',
        quantity: 1,
        price: 0,
      },
      items: [],
    };
  },
  methods: {
    addItem() {
      if (this.newItem.name && this.newItem.quantity > 0 && this.newItem.price > 0) {
        this.items.push({ ...this.newItem });
        this.newItem = { name: '', quantity: 1, price: 0 };
      }
    },
    removeItem(index) {
      this.items.splice(index, 1);
    },
  },
  computed: {
    totalPrice() {
      return this.items.reduce((sum, item) => sum + item.quantity * item.price, 0);
    },
  },
};
</script>

<style scoped>

.container {
  padding: 20px;
  font-family: Arial, sans-serif;
}
.input-group {
  margin-bottom: 20px;
}
input {
  margin-right: 10px;
  padding: 5px;
}
button {
  padding:7px 10px;
  background-color: #054292;
  color: white;
  border: none;
  cursor: pointer;
  font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
}
button:hover {
  background-color: #0576b8;
  border: none;
}
</style>
 