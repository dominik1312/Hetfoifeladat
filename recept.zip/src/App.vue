<template>
  <div class="container mx-auto p-4">
    <h1 class="text-2xl font-bold mb-4">Receptgyűjtemény</h1>
    <form @submit.prevent="addRecipe" class="mb-4">
      <input v-model="newRecipe.name" type="text" placeholder="Recept neve" class="input mb-2"/>
      <textarea v-model="newRecipe.ingredients" placeholder="Hozzávalók vesszővel elválasztva" class="input mb-2"></textarea>
      <input v-model="newRecipe.time" type="number" placeholder="Elkészítési idő (perc)" class="input mb-2"/>
      <textarea v-model="newRecipe.description" placeholder="Leírás" class="input mb-2"></textarea>
      <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Recept hozzáadása</button>
    </form>

    <RecipeList 
      :recipes="recipes" 
      @deleteRecipe="deleteRecipe" 
    />
    
    <p v-if="recipes.length === 0" class="text-center mt-4">Nincs még recept. Adj hozzá egyet!</p>
  </div>
</template>

<script>
import RecipeList from './components/RecipeList.vue';

export default {
  components: {
    RecipeList,
  },
  data() {
    return {
      newRecipe: {
        name: '',
        ingredients: '',
        time: '',
        description: '',
      },
      recipes: [],
    };
  },
  methods: {
    addRecipe() {
      if (
        this.newRecipe.name &&
        this.newRecipe.ingredients &&
        this.newRecipe.time &&
        this.newRecipe.description
      ) {
        const recipe = { 
          ...this.newRecipe, 
          ingredients: this.newRecipe.ingredients.split(',').map(i => i.trim()) 
        };
        this.recipes.push(recipe);
        this.newRecipe = { name: '', ingredients: '', time: '', description: '' };
      }
    },
    deleteRecipe(index) {
      this.recipes.splice(index, 1);
    },
  },
};
</script>

<style scoped>
.input {
  display: block;
  width: 100%;
  margin-bottom: 10px;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}
</style>
