<template>
  <div class="calculator-container">
    <h1 class="title">Számológép</h1>
    <div class="display">{{ display || '0' }}</div>
    <div class="grid grid-cols-4 gap-2">
      <button @click="clear" class="button button-clear">C</button>
      <button @click="appendNumber('7')" class="button">7</button>
      <button @click="appendNumber('8')" class="button">8</button>
      <button @click="appendNumber('9')" class="button">9</button>
      <button @click="setOperation('divide')" class="button button-operation">/</button>

      <button @click="appendNumber('4')" class="button">4</button>
      <button @click="appendNumber('5')" class="button">5</button>
      <button @click="appendNumber('6')" class="button">6</button>
      <button @click="setOperation('multiply')" class="button button-operation">*</button>

      <button @click="appendNumber('1')" class="button">1</button>
      <button @click="appendNumber('2')" class="button">2</button>
      <button @click="appendNumber('3')" class="button">3</button>
      <button @click="setOperation('subtract')" class="button button-operation">-</button>

      <button @click="appendNumber('0')" class="button button-zero">0</button>
      <button @click="appendNumber('.')" class="button">.</button>
      <button @click="calculateResult" class="button button-equals">=</button>
      <button @click="setOperation('add')" class="button button-operation">+</button>
    </div>
    <p v-if="error" class="error">{{ error }}</p>
  </div>
</template>

<script>
export default {
  data() {
    return {
      display: '',
      number1: null,
      number2: null,
      operation: null,
      error: '',
    };
  },
  methods: {
    appendNumber(number) {
      this.error = '';
      if (number === '.' && this.display.includes('.')) return;
      this.display += number;
    },
    setOperation(op) {
      if (this.display) {
        this.number1 = parseFloat(this.display);
        this.display = '';
        this.operation = op;
      }
    },
    calculateResult() {
      if (!this.number1 || !this.display) {
        this.error = 'Kérlek, add meg a számokat!';
        return;
      }
      this.number2 = parseFloat(this.display);
      switch (this.operation) {
        case 'add':
          this.display = this.number1 + this.number2;
          break;
        case 'subtract':
          this.display = this.number1 - this.number2;
          break;
        case 'multiply':
          this.display = this.number1 * this.number2;
          break;
        case 'divide':
          if (this.number2 === 0) {
            this.error = 'A nullával való osztás nem megengedett!';
            this.display = '';
          } else {
            this.display = this.number1 / this.number2;
          }
          break;
      }
      this.number1 = null;
      this.number2 = null;
      this.operation = null;
    },
    clear() {
      this.display = '';
      this.number1 = null;
      this.number2 = null;
      this.operation = null;
      this.error = '';
    },
  },
};
</script>

<style scoped>
.calculator-container {
  max-width: 320px;
  margin: 0 auto;
  padding: 20px;
  background-color: #f0f0f0;
  border-radius: 10px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
}

.title {
  font-size: 1.5rem;
  text-align: center;
  margin-bottom: 10px;
}

.display {
  background-color: #212529;
  color: #ffffff;
  font-size: 2.5rem;
  padding: 20px;
  text-align: right;
  border-radius: 5px;
  margin-bottom: 10px;
  height: 70px;
}

.grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 10px;
}

.button {
  background-color: #ffffff;
  border: 1px solid #cccccc;
  border-radius: 5px;
  padding: 20px;
  font-size: 2rem;
  transition: background-color 0.2s, transform 0.1s;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}

.button:hover {
  background-color: #f1f1f1;
}

.button:active {
  transform: scale(0.95);
}

.button-operation {
  background-color: #f9a825;
  color: white;
}

.button-operation:hover {
  background-color: #f57f17;
}

.button-equals {
  background-color: #4caf50;
  color: white;
  grid-column: span 2;
}

.button-equals:hover {
  background-color: #388e3c;
}

.button-clear {
  background-color: #f44336;
  color: white;
  grid-column: span 2;
}

.button-clear:hover {
  background-color: #e53935;
}

.button-zero {
  grid-column: span 2;
}

.error {
  color: red;
  text-align: center;
  margin-top: 10px;
}
</style>
