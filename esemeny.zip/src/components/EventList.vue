<template>
  <div class="event-list">
    <div 
      v-for="(event, index) in events" 
      :key="index" 
      class="bg-white shadow-md rounded p-4 mb-4"
    >
      <h2 class="text-xl font-bold">{{ event.name }}</h2>
      <p class="italic">Dátum: {{ event.date }}</p>
      <h3 class="font-semibold mt-2">Leírás:</h3>
      <p>{{ event.description }}</p>
      <button 
        @click="$emit('deleteEvent', index)" 
        class="bg-red-500 text-white px-4 py-2 rounded mt-2"
      >
        Törlés
      </button>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    events: Array,
  },
};
</script>
