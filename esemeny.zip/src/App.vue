<template>
  <div class="container mx-auto p-4">
    <h1 class="text-2xl font-bold mb-4">Eseménynaptár</h1>
    <form @submit.prevent="addEvent" class="mb-4">
      <input v-model="newEvent.name" type="text" placeholder="Esemény neve" class="input mb-2"/>
      <input v-model="newEvent.date" type="date" class="input mb-2"/>
      <textarea v-model="newEvent.description" placeholder="Leírás" class="input mb-2"></textarea>
      <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Esemény hozzáadása</button>
    </form>

    <EventList 
      :events="events" 
      @deleteEvent="deleteEvent" 
    />

    <p v-if="events.length === 0" class="text-center mt-4">Nincs még esemény. Adj hozzá egyet!</p>
  </div>
</template>

<script>
import EventList from './components/EventList.vue';

export default {
  components: {
    EventList,
  },
  data() {
    return {
      newEvent: {
        name: '',
        date: '',
        description: '',
      },
      events: [],
    };
  },
  methods: {
    addEvent() {
      if (this.newEvent.name && this.newEvent.date && this.newEvent.description) {
        this.events.push({ ...this.newEvent });
        this.newEvent = { name: '', date: '', description: '' };
      }
    },
    deleteEvent(index) {
      this.events.splice(index, 1);
    },
  },
};
</script>

<style scoped>
.input {
  display: block;
  width: 100%;
  margin-bottom: 10px;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}
</style>
