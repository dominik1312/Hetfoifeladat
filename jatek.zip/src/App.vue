<template>
  <div class="score-counter">
    <h1>Pontszámláló</h1>
    <div v-for="(player, index) in players" :key="index" class="player">
      <h2>{{ player.name }}</h2>
      <input v-model="player.score" type="number" readonly />
      <button @click="increaseScore(index)">Növelés</button>
      <button @click="decreaseScore(index)" :disabled="player.score <= 0">Csökkentés</button>
    </div>
    <button @click="addPlayer">Új játékos hozzáadása</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      players: [
        { name: "Játékos 1", score: 0 },
      ],
    };
  },
  methods: {
    increaseScore(index) {
      this.players[index].score++;
    },
    decreaseScore(index) {
      if (this.players[index].score > 0) {
        this.players[index].score--;
      }
    },
    addPlayer() {
      this.players.push({ name: `Játékos ${this.players.length + 1}`, score: 0 });
    },
  },
};
</script>

<style scoped>
.score-counter {
  text-align: center;
  margin-top: 20px;
}
.player {
  margin: 10px 0;
}
button {
  margin: 5px;
}
</style>
